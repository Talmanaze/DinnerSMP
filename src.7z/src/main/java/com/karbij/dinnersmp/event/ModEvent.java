package com.karbij.dinnersmp.event;

public class ModEvent {
}
